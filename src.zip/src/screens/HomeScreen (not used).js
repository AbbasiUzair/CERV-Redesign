import React from 'react'
import { StyleSheet} from 'react-native'




const HomeScreen = ( {navigation} ) => {
    return (
        <MyTopTabs />
    )
}

const styles = StyleSheet.create({
    viewStyle:{
                
    }
})

export default HomeScreen